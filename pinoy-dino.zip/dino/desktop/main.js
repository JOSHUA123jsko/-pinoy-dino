// Optional: runs the same web app as a transparent, always-on-top overlay.
// Run:  cd desktop && npm install && npm start
// Hide/show: Ctrl+Shift+D.   Quit: close from the tray/taskbar or Ctrl+Shift+Q.
// Note: browser speech recognition (the Listen button) usually does not work inside Electron.
// Voice output, the mute drama, sleep/alarm and boredom all work.
const { app, BrowserWindow, screen, globalShortcut } = require("electron");
const path = require("path");

let win;
function create() {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;
  win = new BrowserWindow({
    width: 480, height: 560, x: width - 500, y: height - 580,
    transparent: true, frame: false, alwaysOnTop: true, resizable: false, hasShadow: false,
    webPreferences: { contextIsolation: true, autoplayPolicy: "no-user-gesture-required" }
  });
  win.setAlwaysOnTop(true, "screen-saver");
  win.loadFile(path.join(__dirname, "..", "index.html"), { query: { overlay: "1" } });
}
app.whenReady().then(() => {
  create();
  globalShortcut.register("Control+Shift+D", () => (win.isVisible() ? win.hide() : win.show()));
  globalShortcut.register("Control+Shift+Q", () => app.quit());
});
app.on("window-all-closed", () => app.quit());
