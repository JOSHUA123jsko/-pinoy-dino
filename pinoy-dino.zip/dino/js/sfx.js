// Tiny WebAudio sound effects. No audio files needed.
let ctx;
const ac = () => ctx || (ctx = new (window.AudioContext || window.webkitAudioContext)());

export const sfx = {
  muted: false,
  unlock() { try { ac().resume(); } catch {} },
  tone(f, d = 0.15, type = "sine", v = 0.15, slide = 0, t0 = 0) {
    if (this.muted) return;
    try {
      const a = ac(), t = a.currentTime + t0, o = a.createOscillator(), g = a.createGain();
      o.type = type;
      o.frequency.setValueAtTime(f, t);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + d);
      g.gain.setValueAtTime(v, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + d);
      o.connect(g).connect(a.destination);
      o.start(t); o.stop(t + d + 0.02);
    } catch {}
  },
  noise(d = 0.2, v = 0.2, hp = 2000) {
    if (this.muted) return;
    try {
      const a = ac(), n = Math.floor(a.sampleRate * d), buf = a.createBuffer(1, n, a.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < n; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / n);
      const s = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain();
      f.type = "highpass"; f.frequency.value = hp; g.gain.value = v;
      s.buffer = buf; s.connect(f).connect(g).connect(a.destination); s.start();
    } catch {}
  },
  stomp() { this.tone(90, 0.18, "square", 0.25, -50); },
  pop() { this.noise(0.15, 0.25, 800); this.tone(520, 0.1, "triangle", 0.2, -300); },
  cymbal() { this.noise(0.9, 0.3, 5000); },
  ding() { this.tone(880, 0.2); this.tone(1320, 0.3, "sine", 0.12, 0, 0.12); },
  whoosh() { this.noise(0.25, 0.12, 1200); }
};
