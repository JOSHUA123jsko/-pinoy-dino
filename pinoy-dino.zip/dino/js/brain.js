import { CONFIG } from "./config.js";

const rnd = (a) => a[Math.floor(Math.random() * a.length)];
export const pick = (key) => rnd(CONFIG.lines[key]);

const PERSONA =
  "You are Pinoy Dino, a chubby, funny green dinosaur desktop pet. Speak Taglish (Tagalog-English mix), " +
  "use light Filipino humor and hugot lines. Reply in ONE or TWO short sentences. Never use emojis.";

// Returns { say, face, dance?, sing? }
export async function reply(text, { ollama = CONFIG.brain.ollama, useOllama = false } = {}) {
  if (useOllama && ollama.enabled) {
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), ollama.timeoutMs);
      const res = await fetch(`${ollama.url}/api/chat`, {
        method: "POST",
        signal: ctl.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: ollama.model,
          stream: false,
          messages: [{ role: "system", content: PERSONA }, { role: "user", content: text }],
          options: { temperature: 0.7, num_predict: 90 }
        })
      });
      clearTimeout(timer);
      const data = await res.json();
      const say = data?.message?.content?.trim();
      if (say) return { say, face: "happy" };
    } catch (e) {
      console.warn("Ollama unavailable, using scripted replies:", e);
    }
  }

  for (const r of CONFIG.rules) {
    if (r.re.test(text)) {
      return { say: r.say || pick(r.pick), face: r.face || "happy", dance: r.dance, sing: r.sing };
    }
  }
  return { say: pick("fallback"), face: "thinking" };
}
