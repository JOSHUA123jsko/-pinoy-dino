import { sfx } from "./sfx.js";

// Browser text-to-speech. Browsers only expose voices installed on the device.
// For a truly custom voice, replace speakAudio() with a call to a TTS API.
export class Voice {
  constructor(cfg) {
    this.cfg = cfg;
    this.synth = "speechSynthesis" in window ? window.speechSynthesis : null;
    this.voices = [];
    this.voice = null;
    this.rate = cfg.rate;
    this.pitch = cfg.pitch;
    this.muted = false;
    this.speaking = false;
    this.onstart = () => {};
    this.onend = () => {};
    this._token = 0;
  }

  sanitize(text) {
    let out = String(text || "");
    for (const w of this.cfg.blocked) out = out.replace(new RegExp(`\\b${w}\\b`, "gi"), "");
    return out.replace(/\s+/g, " ").trim();
  }

  load(savedName) {
    if (!this.synth) return [];
    this.voices = this.synth.getVoices();
    const find = (fn) => this.voices.find(fn);
    let v = savedName && find((x) => x.name === savedName);
    if (!v) {
      for (const lang of this.cfg.preferLang) {
        v = find((x) => x.lang.toLowerCase().startsWith(lang.toLowerCase()));
        if (v) break;
      }
    }
    this.voice = v || this.voices[0] || null;
    return this.voices;
  }

  setVoice(name) {
    const v = this.voices.find((x) => x.name === name);
    if (v) this.voice = v;
  }

  cancel() {
    this._token++;
    if (this.synth) this.synth.cancel();
    if (this.speaking) { this.speaking = false; this.onend(); }
  }

  // Resolves when finished. Muted = silent, but still waits a natural time.
  // opts: { pitch, rate, onBeat }. A "~" in text splits it into separately pitched notes.
  async speak(text, opts = {}) {
    const clean = this.sanitize(text);
    if (!clean) return;
    const token = ++this._token;
    this.speaking = true;
    this.onstart();

    const parts = opts.offKey ? clean.split("~").map((s) => s.trim()).filter(Boolean) : [clean.replace(/~/g, " ")];
    for (const part of parts) {
      if (token !== this._token) return;
      const pitch = opts.offKey ? Math.min(2, Math.max(0.5, this.pitch + (Math.random() - 0.5) * 1.1)) : (opts.pitch ?? this.pitch);
      await this._one(part, pitch, opts.rate ?? (opts.offKey ? 0.85 : this.rate), opts.onBeat, token);
    }
    if (token === this._token) { this.speaking = false; this.onend(); }
  }

  _one(text, pitch, rate, onBeat, token) {
    return new Promise((resolve) => {
      if (this.muted || !this.synth) {
        const t = setInterval(() => token === this._token ? onBeat && onBeat() : clearInterval(t), 260);
        setTimeout(() => { clearInterval(t); resolve(); }, Math.max(700, text.length * 55));
        return;
      }
      const u = new SpeechSynthesisUtterance(text);
      if (this.voice) { u.voice = this.voice; u.lang = this.voice.lang; }
      u.pitch = pitch; u.rate = rate; u.volume = 1;
      u.onboundary = () => onBeat && onBeat();
      u.onend = u.onerror = () => resolve();
      this.synth.speak(u);
    });
  }
}

export { sfx };
