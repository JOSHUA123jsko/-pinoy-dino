export const EXPRESSIONS = ["happy","laughing","angry","sad","excited","shy","surprised","sleepy","thinking","pouty","love","kiss","wink","embarrassed","proud","scared","tired","hurt","cool","angry2","cheerful","hungry","confused","begging","goodbye"];

const $ = (s) => document.querySelector(s);
export const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export class Dino {
  constructor() {
    this.el = $("#dino");
    this.body = $("#body");
    this.sprite = $("#sprite");
    this.bubble = $("#bubble");
    this.captions = true;
    this.x = 50;
    this.current = "happy";
    this._bubbleTimer = 0;
  }

  preload() {
    EXPRESSIONS.forEach((n) => { const i = new Image(); i.src = `assets/sprites/${n}.png`; });
  }

  face(name) {
    if (!EXPRESSIONS.includes(name) || name === this.current) return;
    this.current = name;
    this.sprite.src = `assets/sprites/${name}.png`;
    this.sprite.alt = `Dino looks ${name}`;
    this.restart("pop");
  }

  say(text, ms) {
    clearTimeout(this._bubbleTimer);
    if (!this.captions || !text) { this.bubble.hidden = true; return; }
    this.bubble.textContent = text;
    this.bubble.hidden = false;
    this._bubbleTimer = setTimeout(() => (this.bubble.hidden = true), ms ?? Math.max(2500, text.length * 70));
  }

  hush() { clearTimeout(this._bubbleTimer); this.bubble.hidden = true; }

  talking(on) { this.body.classList.toggle("talking", on); }
  beat() { this.restart("beat"); }

  restart(cls) {
    this.body.classList.remove(cls);
    void this.body.offsetWidth;
    this.body.classList.add(cls);
  }

  // One-shot animation class on the body (dance, hop, stomp...)
  async anim(cls, ms) {
    this.body.classList.add(cls);
    await wait(ms);
    this.body.classList.remove(cls);
  }

  loop(cls, on) { this.body.classList.toggle(cls, on); }

  flip(on) { this.body.classList.toggle("flip", on); }

  async walkTo(pct, ms = 2500) {
    this.flip(pct < this.x);
    this.el.style.transition = `left ${ms}ms linear`;
    this.el.style.left = pct + "%";
    this.loop("waddle", true);
    this.x = pct;
    await wait(ms);
    this.loop("waddle", false);
    this.flip(false);
  }

  rect() { return this.sprite.getBoundingClientRect(); }

  tears(on) { $("#tears").classList.toggle("on", on); }
  zzz(on) { $("#zzz").classList.toggle("on", on); }
}
