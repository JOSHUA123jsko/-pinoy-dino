// All of Dino's settings live here. Edit freely.
export const CONFIG = {
  name: "Pinoy Dino",
  version: "2.0.0", // must match version.json when you ship an update

  voice: {
    blocked: ["yarn"],                 // words removed before speaking
    preferLang: ["fil", "tl", "en-PH", "en"],
    rate: 1.05,
    pitch: 1.5,                        // high-pitched, energetic
    coolPitch: 0.6                     // "Chickboy" sunglasses voice
  },

  schedule: {
    sleep: "22:00",
    wake: "05:00",
    alarmEveryMs: 14000,
    escalationMins: 3,
    snoozeMins: 60
  },

  boredom: { inactivityMins: 15, cooldownMins: 10 },
  idle: { minSec: 45, maxSec: 120 },

  // Mute drama: seconds after pressing Mute when each stage starts
  mute: { begSec: 4, crySec: 9, tantrumSec: 16, sulkSec: 10 },

  // Optional local brain (Ollama). Off by default; scripted replies are used otherwise.
  // Needs: OLLAMA_ORIGINS="*" ollama serve   (so the browser may call it)
  brain: {
    ollama: {
      enabled: false,
      url: "http://localhost:11434",
      model: "qwen2.5:1.5b-instruct-q4_K_M",
      timeoutMs: 20000
    }
  },

  lines: {
    greet: [
      "Uy, gising ka na pala! Kumain ka na ba? Wag puro computer, baka mata mo maging parang keyboard!",
      "Kumusta ka? Ako, okay lang. Drawing lang naman ako."
    ],
    jokes: [
      "Sana all may jowa. Ako kasi, hanggang drawing lang.",
      "Alam mo ba kung bakit malungkot ang calculator? Kasi lahat ng problema niya, siya ang pinapa-solve.",
      "Wag kang mag-alala, ang pera parang ex. Pag hinabol mo, lalayo.",
      "Uminom ka na ba ng tubig? Hydrate! Hindi puro kape at hugot."
    ],
    hugot: [
      "Hindi ako Wi-Fi, pero sana maramdaman mo ang connection natin.",
      "Ikaw ba ay battery? Kasi pag wala ka, namamatay ako.",
      "Ang buhay parang loading screen. Minsan matagal, pero may patutunguhan."
    ],
    cool: [
      "Uy... ang ganda ng araw mo ah. Este, ng screen mo.",
      "Chill lang. Ako na bahala sa good vibes."
    ],
    // "~" splits the line into notes; each note gets a random off-key pitch.
    sing: [
      "La la la~ mahal kita~ pero mas mahal ang kuryente~",
      "Ba ba ba~ sino'ng may meryenda~ ako ba~ ako ba~"
    ],
    poke: [
      "Aray! Ay, ikaw pala. Kala ko multo.",
      "Hihi, nakikiliti ako!",
      "Bakit? Miss mo na ako?"
    ],
    fallback: [
      "Ah, ganun ba? Kwento mo pa.",
      "Sige, nakikinig ako. Promise, hindi ako chismoso.",
      "Hmm, interesting. Tapos?"
    ],
    alarm: [
      "Gising na, madaming pera dyan! Bangon! Alas singko na!",
      "Rise and shine! Mag-ehersisyo tayo!",
      "Bangon na! Ang aga ng ibon, ikaw hindi?"
    ],
    alarmAngry: [
      "Hoy! Gising na nga sabi!",
      "Sige, ihahagis ko na ang unan!"
    ],
    bored: [
      "Ang boring naman! Kunin ko nga tong mga text mo, gawing bola, tapos ihagis!",
      "Trabaho ka ng trabaho, dito ka na lang sa akin!"
    ]
  },

  // Keyword replies. First match wins. face = expression sprite name.
  rules: [
    { re: /\b(hello|hi|hey|kumusta|musta)\b/i, say: "Uy! Kumusta ka? Kumain ka na ba?", face: "happy" },
    { re: /\b(name|pangalan)\b/i, say: "Ako si Pinoy Dino! Ang pinaka-chubby na dinosaur sa screen mo.", face: "proud" },
    { re: /\b(joke|biro|patawa)\b/i, pick: "jokes", face: "laughing" },
    { re: /\b(hugot|love|mahal|jowa)\b/i, pick: "hugot", face: "love" },
    { re: /\b(sing|kanta|kumanta)\b/i, pick: "sing", face: "excited", sing: true },
    { re: /\b(dance|sayaw|sumayaw)\b/i, say: "Game! Budots tayo!", face: "excited", dance: true },
    { re: /\b(sad|malungkot|lungkot|pagod)\b/i, say: "Uy, okay lang yan. Pahinga ka muna, nandito lang ako.", face: "sad" },
    { re: /\b(hungry|gutom|kain)\b/i, say: "Gutom na rin ako! Burger tayo?", face: "hungry" },
    { re: /\b(sleep|tulog|antok)\b/i, say: "Tulog na! Pero after mo muna matapos yan, ha?", face: "sleepy" },
    { re: /\b(thanks|thank you|salamat)\b/i, say: "Walang anuman! Libre lang yan, hindi tulad ng load.", face: "shy" },
    { re: /\b(bye|paalam|goodbye)\b/i, say: "Bye na! Balik ka ha!", face: "goodbye" }
  ]
};
