import { CONFIG as C } from "./config.js";
import { Dino, wait } from "./dino.js";
import { Voice } from "./voice.js";
import { reply, pick } from "./brain.js";
import { sfx } from "./sfx.js";

const $ = (s) => document.querySelector(s);
const rnd = (a) => a[Math.floor(Math.random() * a.length)];
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};

const dino = new Dino();
const voice = new Voice(C.voice);
const S = {
  started: false, mode: "awake", run: 0, lastActive: Date.now(), lastBored: 0,
  snoozeUntil: 0, dramaStage: 0, idleTimer: 0, testSleep: false, wokeAt: 0, muted: false
};
let mouse = { x: innerWidth / 2, y: innerHeight / 2 };

if (new URLSearchParams(location.search).has("overlay")) document.body.classList.add("overlay");

// ---------- helpers ----------
const begin = () => ++S.run;                 // starting a new sequence cancels the old one
const live = (id) => id === S.run;
function setMode(m) { S.mode = m; document.body.dataset.mode = m; $("#status").textContent = `Dino is ${m}`; }
async function waitLive(id, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) { if (!live(id)) return false; await wait(200); }
  return live(id);
}
function calm() {
  voice.cancel();
  dino.hush();
  ["stomp", "sob", "kneel", "turned", "curl", "look", "waddle", "dance", "hop"].forEach((c) => dino.loop(c, false));
  dino.flip(false); dino.tears(false); dino.zzz(false);
  $("#stage").classList.remove("shake");
}
async function talk(text, face = "happy", o = {}) {
  if (S.mode === "sleeping") return;
  dino.face(face);
  dino.say(text, o.ms);
  await voice.speak(text, { pitch: o.pitch, offKey: o.offKey, rate: o.rate, onBeat: () => dino.beat() });
}
const dinoCenter = () => { const r = dino.rect(); return { x: r.left + r.width / 2, y: r.top + r.height * 0.55 }; };
const barH = () => $(".bar").offsetHeight + 16;

voice.onstart = () => { dino.talking(true); mic.pause(); };
voice.onend = () => { dino.talking(false); mic.resume(); };

// ---------- microphone (voice in) ----------
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
const mic = {
  rec: null, on: false,
  init() {
    if (!SR) { $("#mic").disabled = true; $("#mic").title = "Speech recognition needs Chrome or Edge"; return; }
    this.rec = new SR();
    this.rec.continuous = true;
    this.rec.interimResults = false;
    this.rec.lang = store.get("lang", "fil-PH");
    this.rec.onresult = (e) => {
      let t = "";
      for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) t += e.results[i][0].transcript;
      t = t.trim();
      if (t) { this.pause(); heard(t); }
    };
    this.rec.onend = () => { if (this.on && !voice.speaking) setTimeout(() => this.run(), 250); };
    this.rec.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        this.on = false; this.paint(); dino.say("Hindi ko marinig, pa-allow ng mic please.", 4000);
      }
    };
  },
  run() { if (!this.rec || !this.on || voice.speaking) return; try { this.rec.start(); } catch {} },
  pause() { try { this.rec && this.rec.stop(); } catch {} },
  resume() { if (this.on) setTimeout(() => this.run(), 300); },
  toggle() { this.on = !this.on; this.on ? this.run() : this.pause(); this.paint(); },
  paint() {
    const b = $("#mic");
    b.setAttribute("aria-pressed", this.on);
    b.textContent = this.on ? "🎙️ Listening…" : "🎤 Listen";
  }
};

async function heard(text) {
  S.lastActive = Date.now();
  if (S.mode === "sulking") { dino.say("…", 1500); return; }
  if (S.mode !== "awake") return;
  const id = begin();
  dino.face("thinking");
  const r = await reply(text, { useOllama: store.get("ollama", false) });
  if (!live(id)) return;
  if (r.dance) dino.anim("dance", 3500);
  await talk(r.say, r.face, { offKey: r.sing });
  if (live(id)) { dino.face("happy"); scheduleIdle(); }
}

// ---------- sleep & wake ----------
const toMin = (hhmm) => { const [h, m] = hhmm.split(":").map(Number); return h * 60 + m; };
function inSleepWindow(d) {
  const m = d.getHours() * 60 + d.getMinutes(), s = toMin(C.schedule.sleep), w = toMin(C.schedule.wake);
  return s > w ? m >= s || m < w : m >= s && m < w;
}
function sleepVisuals() {
  document.body.classList.add("night");
  dino.face("sleepy"); dino.zzz(true); dino.loop("curl", true);
  dino.say("", 1);
}
async function goSleep(quiet = false) {
  const id = begin();
  clearTimeout(S.idleTimer);
  calm();
  setMode("winding");
  if (!quiet) await talk("Hoaaam… tulog na ako. Good night!", "tired", { pitch: 1.0 });
  if (!live(id)) return;
  setMode("sleeping");
  sleepVisuals();
}
async function startAlarm() {
  const id = begin();
  clearTimeout(S.idleTimer);
  calm();
  setMode("alarm");
  S.alarmStart = Date.now();
  document.body.classList.remove("night");
  $("#snooze").hidden = false;
  let n = 0;
  while (live(id)) {
    const escalated = Date.now() - S.alarmStart > C.schedule.escalationMins * 60000;
    sfx.cymbal();
    dino.anim("hop", 700);
    if (escalated) {
      $("#stage").classList.add("shake");
      throwAt(mouse.x, mouse.y, "pillow");
      talk(pick("alarmAngry"), "angry2", { offKey: true });
    } else {
      talk(pick("alarm"), n % 2 ? "excited" : "cheerful", { offKey: true });
    }
    n++;
    if (!(await waitLive(id, C.schedule.alarmEveryMs))) return;
  }
}
async function stopAlarm(snooze) {
  const id = begin();
  calm();
  $("#snooze").hidden = true;
  S.wokeAt = Date.now();
  if (snooze) {
    S.snoozeUntil = Date.now() + C.schedule.snoozeMins * 60000;
    setMode("winding");
    await talk("Sige, tulog ka pa. Baka pagod ka lang.", "shy");
    if (!live(id)) return;
    setMode("sleeping"); sleepVisuals();
    return;
  }
  S.snoozeUntil = 0;
  setMode("awake");
  await talk("Ayan, gising ka na! Good morning!", "proud");
  scheduleIdle();
}
async function gentleWake() {
  const id = begin();
  calm();
  document.body.classList.remove("night");
  S.snoozeUntil = 0; S.testSleep = false; S.wokeAt = Date.now();
  setMode("awake");
  await talk("Good morning! " + pick("greet"), "happy");
  if (live(id)) scheduleIdle();
}

// ---------- boredom: grab page text, crumple, throw ----------
async function boredom() {
  const id = begin();
  clearTimeout(S.idleTimer);
  calm();
  setMode("bored");
  S.lastBored = Date.now();
  await talk(pick("bored"), "pouty");
  if (!live(id)) return;

  dino.face("thinking");
  const sources = [...document.querySelectorAll("[data-readable]")].filter((e) => e.textContent.trim());
  const src = rnd(sources) || document.body;
  const snippet = (src.textContent.trim().replace(/\s+/g, " ").slice(0, 36)) || "text";
  const from = src.getBoundingClientRect(), to = dinoCenter();
  const fx = $("#fx");

  // pen + letters flying into his hands
  const pen = Object.assign(document.createElement("div"), { className: "pen", textContent: "✏️" });
  pen.style.left = to.x + 50 + "px"; pen.style.top = to.y - 80 + "px";
  fx.append(pen);
  [...snippet.replace(/\s/g, "")].slice(0, 18).forEach((ch, i) => {
    const l = Object.assign(document.createElement("span"), { className: "letter", textContent: ch });
    const sx = from.left + Math.random() * from.width, sy = from.top + Math.random() * from.height;
    l.style.left = sx + "px"; l.style.top = sy + "px";
    fx.append(l);
    const a = l.animate(
      [{ transform: "translate(0,0) scale(1)", opacity: 1 }, { transform: `translate(${to.x - sx}px,${to.y - sy}px) scale(.3)`, opacity: 0.8 }],
      { duration: 900, delay: i * 55, easing: "cubic-bezier(.5,0,.8,.4)", fill: "forwards" }
    );
    a.onfinish = () => l.remove();
  });
  sfx.whoosh();
  if (!(await waitLive(id, 1900))) { fx.replaceChildren(); return; }
  pen.remove();

  // crumple into a ball
  dino.face("excited");
  const ball = Object.assign(document.createElement("div"), { className: "ball" });
  ball.innerHTML = `<span>${snippet.replace(/</g, "&lt;")}</span>`;
  ball.style.transform = `translate(${to.x - 32}px,${to.y - 32}px)`;
  fx.append(ball);
  await wait(500);
  if (!live(id)) { fx.replaceChildren(); return; }

  // throw it toward the farther screen edge
  dino.face("angry2");
  dino.anim("hop", 500);
  sfx.whoosh();
  const dir = to.x < innerWidth / 2 ? 1 : -1;
  const end = await throwBall(ball, to.x - 32, to.y - 32, dir, id);
  ball.remove();
  confetti(Math.min(Math.max(end.x, 20), innerWidth - 20), Math.min(end.y, innerHeight - barH()));
  if (!live(id)) return;

  setMode("awake");
  await talk("Ayan, pop! Ang saya!", "laughing");
  S.lastActive = Date.now();
  dino.face("happy");
  scheduleIdle();
}
function throwBall(ball, x, y, dir, id) {
  return new Promise((res) => {
    let vx = dir * (7 + Math.random() * 3), vy = -13, bounces = 0;
    const floor = innerHeight - barH() - 50;
    (function step() {
      if (!live(id)) return res({ x, y });
      vy += 0.55; x += vx; y += vy;
      if (y > floor) { y = floor; vy *= -0.6; vx *= 0.92; bounces++; sfx.tone(160, 0.08, "sine", 0.1); }
      ball.style.transform = `translate(${x}px,${y}px) rotate(${x * 3}deg)`;
      if (x < -40 || x > innerWidth + 10 || (bounces > 3 && Math.abs(vy) < 1)) return res({ x, y });
      requestAnimationFrame(step);
    })();
  });
}
function confetti(x, y) {
  sfx.pop();
  const colors = ["#5ee6b0", "#ffd45e", "#ff8fa3", "#7cc7ff", "#fff3c9"];
  for (let i = 0; i < 26; i++) {
    const p = Object.assign(document.createElement("i"), { className: "confetti" });
    p.style.left = x + "px"; p.style.top = y + "px"; p.style.background = rnd(colors);
    $("#fx").append(p);
    const ang = Math.random() * Math.PI * 2, d = 60 + Math.random() * 120;
    p.animate(
      [{ transform: "translate(0,0) rotate(0)", opacity: 1 },
       { transform: `translate(${Math.cos(ang) * d}px,${Math.sin(ang) * d + 60}px) rotate(${Math.random() * 720}deg)`, opacity: 0 }],
      { duration: 900 + Math.random() * 500, easing: "ease-out" }
    ).onfinish = () => p.remove();
  }
}
function throwAt(x, y, cls) {
  const from = dinoCenter();
  const el = Object.assign(document.createElement("div"), { className: cls });
  el.style.left = from.x + "px"; el.style.top = from.y + "px";
  $("#fx").append(el);
  sfx.whoosh();
  el.animate(
    [{ transform: "translate(0,0) rotate(0)" }, { transform: `translate(${x - from.x}px,${y - from.y}px) rotate(540deg)` }],
    { duration: 650, easing: "ease-in" }
  ).onfinish = () => { confetti(x, y); el.remove(); };
}

// ---------- mute drama ----------
function setMuted(m) {
  S.muted = m; voice.muted = m; sfx.muted = m;
  const b = $("#mute");
  b.setAttribute("aria-pressed", m);
  b.textContent = m ? "🔇 Unmute" : "🔊 Mute";
  if (m) startDrama(); else endDrama();
}
async function startDrama() {
  if (!["awake", "bored"].includes(S.mode)) { voice.cancel(); return; } // asleep / alarm: mute just mutes
  const id = begin();                     // interrupt everything he was doing
  clearTimeout(S.idleTimer);
  calm();
  $("#fx").replaceChildren();
  setMode("drama");
  const { begSec, crySec, tantrumSec } = C.mute;

  S.dramaStage = 1;
  dino.face("confused"); dino.loop("look", true);
  dino.say("Huh? Bakit ako tahimik? Hello? Test, test?", 4000);
  if (!(await waitLive(id, begSec * 1000))) return;

  S.dramaStage = 2;
  dino.loop("look", false); dino.face("begging"); dino.loop("kneel", true);
  dino.say("Please, wag mo akong i-mute! Tatahimik na ako, promise!", 5000);
  if (!(await waitLive(id, (crySec - begSec) * 1000))) return;

  S.dramaStage = 3;
  dino.face("sad"); dino.tears(true); dino.loop("sob", true);
  dino.say("Ang sama mo! Wala ka nang pakialam sa akin!", 6000);
  if (!(await waitLive(id, (tantrumSec - crySec) * 1000))) return;

  S.dramaStage = 4;
  dino.tears(false); dino.loop("sob", false); dino.loop("kneel", false);
  dino.face("angry2");
  dino.say("Fine! Bahala ka sa buhay mo!", 4000);
  for (let i = 0; i < 5; i++) {
    sfx.stomp(); dino.anim("stomp", 450);
    if (!(await waitLive(id, 900))) return;
  }
  dino.face("pouty"); dino.loop("turned", true);
  dino.say("Hmp.", 3000);
}
async function endDrama() {
  if (S.mode !== "drama") return;
  const stage = S.dramaStage;
  const id = begin();
  calm();
  if (stage <= 1) {
    setMode("awake");
    await talk("Ay, buti binalik mo! Kinabahan ako dun.", "surprised");
    scheduleIdle();
    return;
  }
  setMode("sulking");                      // refuses to talk until you click him (or ~10 s)
  dino.face("pouty"); dino.loop("turned", true);
  dino.say("…", 2000);
  const end = Date.now() + C.mute.sulkSec * 1000;
  let k = 0;
  while (Date.now() < end) {
    if (!(await waitLive(id, 2500))) return;
    dino.face(k++ % 2 ? "pouty" : "cool");   // side-eye
  }
  if (live(id)) forgive(false);
}
async function forgive(clicked) {
  const id = begin();
  calm();
  S.wokeAt = Date.now();
  setMode("awake");
  await talk(
    clicked ? "Hmp… sige na nga. Napatawad na kita!" : "Hmp. Sige, okay na. Wag mo na ulit gawin yun!",
    clicked ? "love" : "shy"
  );
  if (live(id)) scheduleIdle();
}

// ---------- idle life ----------
function scheduleIdle() {
  clearTimeout(S.idleTimer);
  const { minSec, maxSec } = C.idle;
  S.idleTimer = setTimeout(idle, (minSec + Math.random() * (maxSec - minSec)) * 1000);
}
async function idle() {
  if (S.mode !== "awake" || voice.speaking) return scheduleIdle();
  const id = begin();
  const act = rnd(["joke", "hugot", "dance", "cool", "walk", "sing"]);
  if (act === "joke") await talk(pick("jokes"), "laughing");
  else if (act === "hugot") await talk(pick("hugot"), "love");
  else if (act === "sing") { dino.anim("dance", 3000); await talk(pick("sing"), "excited", { offKey: true }); }
  else if (act === "dance") { dino.face("excited"); await dino.anim("dance", 3500); }
  else if (act === "walk") await dino.walkTo(15 + Math.random() * 70);
  else if (act === "cool") {
    dino.face("cool");
    await talk(pick("cool"), "cool", { pitch: C.voice.coolPitch });
    await wait(2500);
  }
  if (live(id)) { dino.face("happy"); scheduleIdle(); }
}

// ---------- clock ----------
function tick() {
  if (!S.started) return;
  const now = Date.now();
  const sleepy = inSleepWindow(new Date());
  if (S.mode === "awake" && sleepy) return void goSleep();
  if (S.mode === "sleeping" && !sleepy && !S.testSleep && now >= S.snoozeUntil) {
    return void (now - S.lastActive > 60000 ? startAlarm() : gentleWake());
  }
  if (S.mode === "awake" && !voice.speaking &&
      now - S.lastActive > C.boredom.inactivityMins * 60000 &&
      now - S.lastBored > C.boredom.cooldownMins * 60000) boredom();
}

// ---------- input ----------
const touch = () => (S.lastActive = Date.now());
addEventListener("pointermove", (e) => { mouse = { x: e.clientX, y: e.clientY }; touch(); });
const wakeOnInput = (e) => {
  touch();
  if (S.mode === "alarm" && !(e.target.closest && e.target.closest("#snooze, #mute"))) stopAlarm(false);
};
addEventListener("pointerdown", wakeOnInput);
addEventListener("keydown", wakeOnInput);

$("#dino").addEventListener("click", () => {
  if (!S.started || Date.now() - S.wokeAt < 600) return;
  touch();
  if (S.mode === "sulking") return void forgive(true);
  if (S.mode === "sleeping") {
    if (S.testSleep) return void gentleWake();
    dino.face("tired"); dino.say("Zzz… five minutes pa…", 2500);
    return;
  }
  if (S.mode !== "awake") return;
  const id = begin();
  dino.anim("hop", 600);
  talk(pick("poke"), rnd(["surprised", "laughing", "shy", "love"])).then(() => live(id) && scheduleIdle());
});

$("#mute").addEventListener("click", () => setMuted(!S.muted));
$("#mic").addEventListener("click", () => mic.toggle());
$("#snooze").addEventListener("click", () => stopAlarm(true));
$("#gear").addEventListener("click", () => {
  const p = $("#panel");
  p.hidden = !p.hidden;
  $("#gear").setAttribute("aria-expanded", !p.hidden);
});

// settings panel
function fillVoices() {
  const list = voice.load(store.get("voiceName", null));
  const sel = $("#voiceSel");
  sel.replaceChildren(...(list.length ? list.map((v) => new Option(`${v.name} (${v.lang})`, v.name)) : [new Option("Default voice", "")]));
  if (voice.voice) sel.value = voice.voice.name;
}
$("#voiceSel").addEventListener("change", (e) => { voice.setVoice(e.target.value); store.set("voiceName", e.target.value); });
$("#rate").addEventListener("input", (e) => { voice.rate = +e.target.value; store.set("rate", voice.rate); });
$("#pitch").addEventListener("input", (e) => { voice.pitch = +e.target.value; store.set("pitch", voice.pitch); });
$("#captions").addEventListener("change", (e) => { dino.captions = e.target.checked; store.set("captions", e.target.checked); if (!e.target.checked) dino.hush(); });
$("#lang").addEventListener("change", (e) => {
  store.set("lang", e.target.value);
  if (mic.rec) { mic.rec.lang = e.target.value; if (mic.on) { mic.pause(); mic.resume(); } }
});
$("#ollama").addEventListener("change", (e) => { store.set("ollama", e.target.checked); C.brain.ollama.enabled = e.target.checked; });
$("#tSleep").addEventListener("click", () => { S.testSleep = true; goSleep(); });
$("#tAlarm").addEventListener("click", () => startAlarm());
$("#tBored").addEventListener("click", () => { if (S.mode === "awake") boredom(); });
$("#tMute").addEventListener("click", () => { if (!S.muted) setMuted(true); });
$("#tSing").addEventListener("click", () => { if (S.mode === "awake") talk(pick("sing"), "excited", { offKey: true }); });

// ---------- auto-update ----------
async function checkUpdate() {
  try {
    const r = await fetch("version.json?" + Date.now(), { cache: "no-store" });
    const v = await r.json();
    if (v.version && v.version !== C.version) {
      const b = $("#update");
      b.hidden = false;
      b.textContent = `Update ${v.version} ready — tap to reload`;
      sfx.ding();
    }
  } catch {}
}
$("#update").addEventListener("click", () => location.reload());
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});

// ---------- start ----------
$("#rate").value = voice.rate = store.get("rate", C.voice.rate);
$("#pitch").value = voice.pitch = store.get("pitch", C.voice.pitch);
$("#captions").checked = dino.captions = store.get("captions", true);
$("#lang").value = store.get("lang", "fil-PH");
$("#ollama").checked = C.brain.ollama.enabled = store.get("ollama", false);
if (voice.synth) { voice.synth.onvoiceschanged = fillVoices; fillVoices(); }
else $("#voiceSel").replaceChildren(new Option("Speech not supported", ""));
dino.preload();

$("#startBtn").addEventListener("click", async () => {
  sfx.unlock();
  S.started = true;
  $("#start").hidden = true;
  mic.init(); mic.paint();
  checkUpdate();
  setInterval(checkUpdate, 6 * 3600 * 1000);
  setInterval(tick, 5000);
  const prev = store.get("ver", null);
  store.set("ver", C.version);
  if (inSleepWindow(new Date())) return void goSleep(true);
  setMode("awake");
  if (prev && prev !== C.version) await talk("Uy, nag-update ako! Mas pogi na ako ngayon.", "proud");
  else await talk(pick("greet"), "happy");
  scheduleIdle();
});
