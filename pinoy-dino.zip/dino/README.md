# Pinoy Dino

A talkative Taglish dinosaur companion for your screen. Static web app, ready for GitHub Pages.

## Put it on GitHub
1. Create a repository and upload everything in this folder to the root.
2. Settings → Pages → Source: **GitHub Actions** (the workflow in `.github/workflows/pages.yml` deploys it).
   Or choose "Deploy from a branch", branch `main`, folder `/ (root)`.
3. Open the Pages URL, tap **Gisingin si Dino**.

Run locally: `python3 -m http.server 8080` then open http://localhost:8080

## Controls
- **Mute**: try it. He overreacts.
- **Listen**: he hears you and answers by voice. Pick "I understand" language in ⚙️.
- ⚙️ also has **Try it now** buttons (Sing, Bored, Mute drama, Sleep, Alarm) so you do not have to wait until 10 PM or 15 minutes.
- Click him for a reaction. Click him while sulking to apologize.

## Files
| Path | What it does |
|---|---|
| `index.html`, `styles.css` | Page and look |
| `js/config.js` | All settings, schedule, Taglish lines and keyword replies. Edit here. |
| `js/main.js` | Behaviors: mute drama, sleep/alarm, boredom, idle, mic |
| `js/dino.js`, `js/voice.js`, `js/brain.js`, `js/sfx.js` | Sprite/animation, speech, replies, sound effects |
| `assets/sprites/` | 25 expressions cut from your character sheet (transparent PNG) |
| `version.json`, `sw.js`, `manifest.webmanifest` | Update check, offline cache, installable app |
| `desktop/` | Optional Electron wrapper: transparent always-on-top overlay |
| `knowledge-base/` | Optional local-brain files (`knowledge.yaml`, `scan.sh`) |

## Shipping an update
Change `version` in both `js/config.js` and `version.json`, push. Open tabs show "Update ready — tap to reload", and after reload he says "Uy, nag-update ako!".

## Desktop overlay (optional)
`cd desktop && npm install && npm start`. Ctrl+Shift+D hides/shows him. The Listen button usually does not work inside Electron; everything else does.

## Local AI brain (optional)
1. Install Ollama and run `ollama pull qwen2.5:1.5b-instruct-q4_K_M`.
2. Start it allowing the browser: `OLLAMA_ORIGINS="*" ollama serve`.
3. Use the app on `http://localhost` (a GitHub Pages https page cannot call a local http server in most browsers), tick **Use local Ollama brain** in ⚙️.
If Ollama is not reachable he falls back to the scripted replies.
For answering from your own notes, set up AnythingLLM with `knowledge-base/knowledge.yaml` as described in that file's comments; Dino does not read your files by itself.

## Custom voice
Browsers only offer installed voices. Replace `Voice._one()` in `js/voice.js` with a call to a TTS service (Azure, ElevenLabs, local Coqui) that returns audio, and play it.

## Known rough edges
- Sprites were auto-cut from the sheet; a few have small leftover edge pixels. Swap in cleaner PNGs with the same names anytime.
- Singing uses original silly lyrics, off-key by random pitch, not real songs.
