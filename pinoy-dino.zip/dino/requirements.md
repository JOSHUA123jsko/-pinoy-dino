# Requirements

## Must work (web app)
- Static files only, no build step. Deployable on GitHub Pages.
- Mic and sound start only after the user taps "Gisingin si Dino".
- Dino talks by voice. No chat window and no chat history. Speech bubbles show only the current line and can be turned off.
- Replies when you speak (Chrome/Edge). Mic pauses while he speaks, then resumes.
- The word "yarn" is removed before anything is spoken.
- Voice picker, speed and pitch are saved in localStorage.
- 25 expressions from the character sheet drive his face.
- Mute drama: confused, begging, crying, tantrum, then sulking after unmute (about 10 s, or click him to apologize).
- Sleeps at 22:00 (dim, Zzz, silent). Alarm at 05:00 with escalation after 3 min. Snooze button.
- Boredom after 15 min of no input: copies text from the page, crumples it, throws it, pops into confetti.
- Idle life: jokes, hugot lines, off-key singing, dancing, walking, sunglasses "Chickboy" mode.
- Update check against version.json plus a network-first service worker.

## Browser support
- Chrome, Edge: full support.
- Safari, Firefox: voice output works; speech recognition varies or is missing.

## Limits to know
- The browser tab (or the desktop wrapper) must stay open for the clock, alarm and boredom to run.
- A web page cannot read other windows. Real screen OCR needs the desktop wrapper plus extra code (e.g. tesseract.js).
- Mouth shapes are approximated by a talking bounce, not per-vowel lip-sync, because the mouth chart is not rigged.
- Browsers only expose installed voices. For a custom voice, replace `Voice._one()` in js/voice.js with a TTS API that returns audio.
