#!/usr/bin/env bash
# Run before installing: checks RAM, disk and your files folder.
set -e
echo "=== RAM ===";            free -h
echo "=== Disk space ===";     df -h .
echo "=== File types in ./files ==="
find ./files -type f 2>/dev/null | sed 's/.*\.//' | sort | uniq -c | sort -nr
echo "=== Folder size ===";    du -sh ./files 2>/dev/null || echo "Create ./files first"
echo "=== Large files (>50 MB) ==="
find ./files -type f -size +50M -print 2>/dev/null
echo "=== YAML check ==="
python3 -c "import yaml; yaml.safe_load(open('knowledge.yaml')); print('YAML OK')"
